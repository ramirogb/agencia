-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 27-12-2009 a las 23:09:31
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de datos: `agencia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agencias`
--

DROP TABLE IF EXISTS `agencias`;
CREATE TABLE IF NOT EXISTS `agencias` (
  `EmpCdg` char(2) NOT NULL,
  `AgeCdg` char(3) NOT NULL,
  `AgeDsc` varchar(50) NOT NULL,
  `AgeDscAbr` varchar(20) NOT NULL,
  `AgeDir` varchar(50) default NULL,
  `AgeFon` varchar(20) default NULL,
  `AgeFax` varchar(20) default NULL,
  `AgeCto` varchar(50) default NULL,
  `AgeUsuAdd` char(4) default NULL,
  `AgeFecAdd` date default NULL,
  `AgeTimAdd` char(14) default NULL,
  `AgeUsuChg` char(4) default NULL,
  `AgeFecChg` date default NULL,
  `AgeTimChg` char(14) default NULL,
  `AgeRuc` varchar(12) default NULL,
  `Color1` int(11) default NULL,
  `Color2` int(11) default NULL,
  `AgeFon2` varchar(20) default NULL,
  `AgeNex` varchar(20) default NULL,
  `AgeCelMov` varchar(20) default NULL,
  `AgeCelCla` varchar(20) default NULL,
  `Rng` varchar(21) default NULL,
  PRIMARY KEY  (`EmpCdg`,`AgeCdg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `agencias`
--

INSERT INTO `agencias` (`EmpCdg`, `AgeCdg`, `AgeDsc`, `AgeDscAbr`, `AgeDir`, `AgeFon`, `AgeFax`, `AgeCto`, `AgeUsuAdd`, `AgeFecAdd`, `AgeTimAdd`, `AgeUsuChg`, `AgeFecChg`, `AgeTimChg`, `AgeRuc`, `Color1`, `Color2`, `AgeFon2`, `AgeNex`, `AgeCelMov`, `AgeCelCla`, `Rng`) VALUES
('', 'yy', 'y', 'y', 'y', 'y', 'y', 'y', 'y', '0000-00-00', '6', '6', '0000-00-00', '6', '6', NULL, NULL, '6', '6', '666', '666666666666', NULL),
('01', 'COT', 'CONRESA TOUR ', 'COT', 'Av. Mariscal Benavides 183 Urb. Selva Alegre ', '285420', NULL, 'ERICKA CRISTOSO', 'ADMN', '2008-12-08', '09:55:26 a.m.', 'A001', '2009-04-15', '16:41:18', NULL, 16711680, 12639424, '247186', '402*9611', NULL, NULL, NULL),
('01', 'CON', 'CONTACTUS', 'CON', '', '01271-7552', '', 'DIEGO RODIL', 'ADMN', '2008-12-08', '09:55:42 a.m.', 'A001', '2009-04-15', '16:40:14', '', 16711680, 15780518, '', '', '', '', NULL),
('01', 'IKL', 'INKALAND TOURS', 'INKALAND TOURS', 'AV. LOS LIBERTADORES 445 SAN ISIDRO - LIMA', '012222291', '014228540', 'CARMEN HERBOZO', 'ADMN', '2008-12-08', '09:54:57 a.m.', 'A001', '2009-04-15', '16:46:22', NULL, 16711680, 65280, NULL, NULL, '01997 576 479', '88', NULL),
('01', 'ANT', 'ANDEAN TOUR', 'ANT', 'CALLE SCHELL 319 OF. 306 MIRAFLORES - LIMA', '014467992', '', 'JAVIER VILLA', 'ADMN', '2008-12-08', '09:55:11 a.m.', 'ADMN', '2009-11-23', '01:19:40', '20111490571', 16711680, 15780518, '', '', '01993504776', '', '2009-01-01 2009-12-31'),
('01', 'CAT', 'CLASS ADVENTURE TRAVEL', 'CLASS ADVENTURE TRAV', 'LIMA', '01444 2220', '', 'HECTOR LUJAN', 'ADMN', '2008-12-07', '05:07:33 p.m.', 'ADMN', '2009-11-23', '10:33:57', '20806580989', 16711680, 15780518, '', '', '', '01989123176', '2009-01-01 2009-12-31'),
('01', 'ATA', 'ACUARIOS TRAVEL', 'ACUARIOS', 'CALLE SANTA CATALINA 104', '247393', '247393', 'LOURDES PEÑA', 'ADMN', '2008-12-08', '09:53:18 a.m.', 'A001', '2009-04-15', '16:21:48', '', 16711680, 12639424, '284705', '', '9996979', '', NULL),
('01', 'INR', 'INCA ROUTE', 'INR', 'Malecon Socabaya 306 IV Centenario', '200920', '226053', 'MARITA BELLATIN', 'ADMN', '2008-12-08', '09:56:15 a.m.', 'A001', '2009-04-15', '16:50:32', '', 16711680, 12639424, '', '406*6352', '', '', NULL),
('01', 'INT', 'INKARI TOURS', 'INT', 'Federico Villarreal 252 Of 101', '01- 421 87 05', '01 - 442 15 59', 'GERALDINE', 'ADMN', '2008-12-08', '09:56:36 a.m.', 'A001', '2009-04-15', '16:53:05', '', 16711680, 15780518, '01 - 421 42 63', '', '', '', NULL),
('01', 'LAT', 'LATIN TOURS', '', '', '014264287 ', '', 'JOSE', 'ADMN', '2008-12-08', '09:56:47 a.m.', 'A001', '2009-04-15', '16:58:44', '', 16711680, 15780518, '', ' (9) 421*6644', '', '', NULL),
('01', 'PEC', 'PERUVIAN CONFORT', '', '', '', '', '', 'ADMN', '2008-12-08', '09:57:00 a.m.', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('01', 'PTA', 'PLANET TRAVEL AREQUIPA', '', 'JERUSALEN 519', '200009', '', 'EDY DIAZ', 'ADMN', '2008-12-08', '09:57:22 a.m.', 'A001', '2009-04-15', '17:12:30', '', 16711680, 12639424, '200029', '', '959616090', '', NULL),
('01', 'PTP', 'PLANET TRAVEL PUNO', '', '', '', '', '', 'ADMN', '2008-12-08', '09:57:34 a.m.', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('01', 'SIT', 'SIHAI TIANMA', '', '', '', '', '', 'ADMN', '2008-12-08', '09:57:47 a.m.', 'A001', '2009-01-05', '12:21:12', '', 16711680, 15780518, NULL, NULL, NULL, NULL, NULL),
('01', 'ANE', 'ANDES EXPLORER', 'ANE', 'CALLE MELGAR 101', '223747', '', 'GINA', 'ADMN', '2008-12-08', '09:58:00 a.m.', 'A001', '2009-04-15', '16:18:43', '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'MAP', 'MARAVILLAS PERUANAS', '', '', '200970', '', 'JACQUELIN QUINTANILLA', 'ADMN', '2008-12-08', '09:58:14 a.m.', 'A001', '2009-04-15', '17:01:17', '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'CTK', 'COLCA TREKK', 'CTK', 'Calle Jerusalen 401-B', '206217 ', '', 'MERCEDES VALDIVIA', 'ADMN', '2008-12-08', '09:59:23 a.m.', 'A001', '2009-04-15', '16:42:25', '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'PEL', 'PERU LINE', '', 'Av. Grau 255, Miraflores', '01242 3642', '01242 3642', 'SANDRA WOLF', 'ADMN', '2008-12-08', '09:59:38 a.m.', 'A001', '2009-04-15', '17:11:31', '', 16711680, 15780518, '', '', '', '', NULL),
('01', 'CAR', 'CALYPSO REPS', '', '', '', '', '', 'ADMN', '2008-12-08', '09:59:50 a.m.', 'A001', '2009-01-05', '12:17:41', '', 16711680, 15780518, NULL, NULL, NULL, NULL, NULL),
('01', 'TPL', 'TRAVEL PERU ONLINE', '', '', '', '', '', 'ADMN', '2008-12-08', '10:00:02 a.m.', 'A001', '2009-01-05', '12:21:27', '', 16711680, 15780518, NULL, NULL, NULL, NULL, NULL),
('01', 'HOT', 'HOPE TRAVEL', '', '', '', '', '', 'ADMN', '2008-12-08', '10:00:13 a.m.', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('01', 'RAT', 'RAYMI TOUR', '', '', '', '', '', 'ADMN', '2008-12-08', '10:00:30 a.m.', 'A001', '2009-01-05', '12:21:06', '', 16711680, 15780518, NULL, NULL, NULL, NULL, NULL),
('01', 'MET', 'META TRAVEL', 'MET', '', '01628 2186', '', 'SUSANA AGUIRRE', 'ADMN', '2008-12-08', '10:00:40 a.m.', 'A001', '2009-04-15', '17:08:42', '20518900944', 16711680, 15780518, '', '', '01993827920 ', '', NULL),
('01', 'AWT', 'ALL WAYS TRAVEL', '', '', '', '', '', 'ADMN', '2008-12-08', '10:00:56 a.m.', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('01', 'SVP', 'SIERRA VERDE PERU', '', '', '', '', '', 'ADMN', '2008-12-08', '10:02:23 a.m.', 'A001', '2009-01-05', '12:21:18', '', 16711680, 15780518, NULL, NULL, NULL, NULL, NULL),
('01', 'GSA', 'GSA AREQUIPA', 'GSA', 'PORTAL SAN AGUSTIN 111', '202427', '', 'SERGIO CUEVA', 'ADMN', '2008-12-10', '08:18:23 p.m.', 'A001', '2009-04-15', '16:45:20', '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'PAT', 'PERU AVENTURA TOURS', 'PERU AVENTURA', 'lima', '01445-3315', '', '', 'ADMN', '2008-12-13', '11:01:08 a.m.', 'A001', '2009-04-15', '17:10:27', '21323334', 16711680, 15780518, '', '*105*9662', '01997 272 115', '', NULL),
('01', 'IKP', 'INKAS PARADISE', 'IKP', 'Mariscal Gamarra 5', '84-229311', '', 'ESTHER TITO', 'ADMN', '2008-12-27', '12:41:00 p.m.', 'A001', '2009-04-15', '16:48:21', '', 0, 0, '84-223228', '', '84-9761226', '', NULL),
('01', 'MTA', 'MIRS TRAVEL', 'MIT', 'Colón 301 3240 - Villaguay - E.R.Argentina', '54 3455 423790', '', 'SERGIO MIRANDA', 'A001', '2009-01-23', '11:48:43', 'A001', '2009-01-23', '11:53:43', '', 16711680, 12639424, '', '', '00 54 93455 624365', '', NULL),
('01', 'MEP', 'MUNDO ESCONDIDO PERU', 'MEP', '', '', '', 'CINTIA MIMBELA', 'A001', '2009-06-09', '07:53:47', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'TIN', 'TIERRA INCA', 'TIN', '', '084-260160', '', 'JUAN ZARATE', 'A001', '2009-06-16', '05:17:06', 'A001', '2009-06-16', '05:24:37', '', 16711680, 12639424, '', '', '084-984622080', '', NULL),
('01', 'NEP', 'NIKOL EXPEDITIONS PERU', 'NEP', '', '', '', '', 'A001', '2009-06-22', '06:43:17', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'ZZZ', 'AGENCIA ZZZ PRUEBA', 'PRUEBA', '', '', '', '', 'A002', '2009-06-30', '04:25:01 p.m.', NULL, NULL, NULL, '', 16711680, 15780518, '', '', '', '', NULL),
('01', 'VRT', 'VIRREYNAL TOURS', 'VIRREYNAL TOURS', 'Shell 120 Of. 24', '01445-8844', '', 'SUSANA', 'A001', '2009-07-09', '17:18:39', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'CLT', 'CLARISA TOURS', 'CLT', '', '', '', 'CLARA LUISA', 'A001', '2009-07-11', '13:25:48', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'ESA', 'EXPLORING SUDAMERICA', 'ESA', '', '', '', '', 'A001', '2009-08-31', '11:40:07', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'PTG', 'PILGRIM TRAVEL', 'PTG', '', '', '', '', 'A001', '2009-10-02', '11:20:01', NULL, NULL, NULL, '', 16711680, 12639424, '', '', '', '', NULL),
('01', 'KTK', 'KONTIKI', '', '', '', '', '', 'A001', '2009-10-24', '11:49:46', 'A001', '2009-10-24', '11:51:16', '', 16711680, 12639424, '', '', '', '', NULL),
('1', 'mmx', 'Agencia Ramiro SAC', 'Agencia dedicada a l', 'Los geranios', '444444', '222222', 'ramiro', '1', NULL, NULL, '1', '0000-00-00', '1', '2147483647', 1, 1, '545', '545', '454', '545', '1'),
('1', '44', '44', '4', '4', '444444', '4', '4', '1', NULL, NULL, '1', '0000-00-00', '1', '4', 1, 1, '4', '4', '4', '4', '1');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `esta`
--
CREATE TABLE IF NOT EXISTS `esta` (
`EmpCdg` char(2)
,`DocNro` char(10)
,`AgeCdg` char(3)
,`Paxs` int(11)
,`Dsc` varchar(100)
,`SerNum` int(11)
,`NumSerDet` int(11)
,`NumPaxDet` int(11)
,`ImpValVta` float
,`ImpIgv` float
,`ImpTot` float
,`ImpIgvNow` float
,`MonTip` char(1)
,`Sts` char(1)
,`AnuFlg` char(1)
,`ValPreFlg` char(1)
,`FacNro` char(10)
,`PndFlg` char(1)
,`StsPnd` char(1)
,`FecLimPrePag` date
,`Obs` mediumblob
,`Ema` varchar(254)
,`DocRes` varchar(20)
,`PerRes` varchar(50)
,`UsuAdd` char(4)
,`FecAdd` date
,`TimAdd` char(14)
,`UsuChg` char(4)
,`FecChg` date
,`TimChg` char(14)
,`fectrn` date
,`ImpTipCam` float
,`AfeIgvflg` char(1)
,`FecPriSer` date
,`EmailEnviado` mediumblob
,`EmailRecibido` mediumblob
,`FileHTML` varchar(254)
,`Length` int(11)
,`EmaFlg` char(1)
,`Color1` int(11)
,`Color2` int(11)
,`tipe` varchar(1)
,`lang` varchar(5)
,`comment` varchar(200)
,`catalog_prom` varchar(10)
,`timestamp` bigint(10)
,`SerCdg` varchar(10)
,`price1` float
,`pricet` float
,`promo_cat` varchar(10)
,`cur_datime` bigint(10)
,`attention` varchar(20)
);
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `myreservas`
--

DROP TABLE IF EXISTS `myreservas`;
CREATE TABLE IF NOT EXISTS `myreservas` (
  `EmpCdg` char(2) NOT NULL,
  `DocNro` char(10) NOT NULL,
  `AgeCdg` char(3) default NULL,
  `Paxs` int(11) default NULL,
  `Dsc` varchar(100) default NULL,
  `SerNum` int(11) default NULL,
  `NumSerDet` int(11) default NULL,
  `NumPaxDet` int(11) default NULL,
  `ImpValVta` float default NULL,
  `ImpIgv` float default NULL,
  `ImpTot` float default NULL,
  `ImpIgvNow` float default NULL,
  `MonTip` char(1) default NULL,
  `Sts` char(1) default NULL,
  `AnuFlg` char(1) default NULL,
  `ValPreFlg` char(1) default NULL,
  `FacNro` char(10) default NULL,
  `PndFlg` char(1) default NULL,
  `StsPnd` char(1) default NULL,
  `FecLimPrePag` date default NULL,
  `Obs` mediumblob,
  `Ema` varchar(254) default NULL,
  `DocRes` varchar(20) default NULL,
  `PerRes` varchar(50) default NULL,
  `UsuAdd` char(4) default NULL,
  `FecAdd` date default NULL,
  `TimAdd` char(14) default NULL,
  `UsuChg` char(4) default NULL,
  `FecChg` date default NULL,
  `TimChg` char(14) default NULL,
  `fectrn` date default NULL,
  `ImpTipCam` float default NULL,
  `AfeIgvflg` char(1) default NULL,
  `FecPriSer` date default NULL,
  `EmailEnviado` mediumblob,
  `EmailRecibido` mediumblob,
  `FileHTML` varchar(254) default NULL,
  `Length` int(11) default NULL,
  `EmaFlg` char(1) default NULL,
  `Color1` int(11) default NULL,
  `Color2` int(11) default NULL,
  `tipe` varchar(1) NOT NULL,
  `lang` varchar(5) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `catalog_prom` varchar(10) NOT NULL,
  `timestamp` bigint(10) NOT NULL,
  `SerCdg` varchar(10) NOT NULL,
  `price1` float NOT NULL,
  `pricet` float NOT NULL,
  `promo_cat` varchar(10) NOT NULL,
  `cur_datime` bigint(10) NOT NULL,
  `attention` varchar(20) NOT NULL,
  PRIMARY KEY  (`SerCdg`,`DocNro`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `myreservas`
--

INSERT INTO `myreservas` (`EmpCdg`, `DocNro`, `AgeCdg`, `Paxs`, `Dsc`, `SerNum`, `NumSerDet`, `NumPaxDet`, `ImpValVta`, `ImpIgv`, `ImpTot`, `ImpIgvNow`, `MonTip`, `Sts`, `AnuFlg`, `ValPreFlg`, `FacNro`, `PndFlg`, `StsPnd`, `FecLimPrePag`, `Obs`, `Ema`, `DocRes`, `PerRes`, `UsuAdd`, `FecAdd`, `TimAdd`, `UsuChg`, `FecChg`, `TimChg`, `fectrn`, `ImpTipCam`, `AfeIgvflg`, `FecPriSer`, `EmailEnviado`, `EmailRecibido`, `FileHTML`, `Length`, `EmaFlg`, `Color1`, `Color2`, `tipe`, `lang`, `comment`, `catalog_prom`, `timestamp`, `SerCdg`, `price1`, `pricet`, `promo_cat`, `cur_datime`, `attention`) VALUES
('', 'DAT-1', 'DAT', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'fr', 'comentario esto es lo que yo opino de esto no debe contener estas caracteristicas ok????????', '', 0, 'AE02', 50, 0, '', 1261445998, ''),
('', 'DAT-1', 'DAT', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', 'es', 'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv', '', 0, 'AE08', 327.5, 0, '', 1261445998, ''),
('', 'IKP-1', 'IKP', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'es', 'bla ble bli bo', '', 0, '2', 20, 0, '', 1261929568, ''),
('', 'IKP-2', 'IKP', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'es', 'bla ble bli bo', '', 0, '2', 20, 0, '', 1261929764, ''),
('', 'IKP-3', 'IKP', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'es', 'bla ble bli bo', '', 0, '2', 20, 0, '', 1261929816, ''),
('', 'IKP-4', 'IKP', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'es', 'bla ble bli bo', '', 0, '2', 20, 0, '', 1261929838, ''),
('', 'IKP-5', 'IKP', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'es', 'bla ble bli bo', '', 0, '2', 20, 0, '', 1261929856, ''),
('', 'IKP-6', 'IKP', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 'dddddd', '', 0, '2', 20, 0, '', 1261930213, ''),
('', 'IKP-6', 'IKP', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 0, '', 0, 0, '', 1261930213, ''),
('', 'IKP-8', 'IKP', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 'dddddd', '', 0, '2', 20, 0, '', 1261930243, ''),
('', 'IKP-8', 'IKP', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 0, '', 0, 0, '', 1261930243, ''),
('', 'IKP-10', 'IKP', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 'dddddd', '', 0, '2', 20, 0, '', 1261931032, ''),
('', 'IKP-10', 'IKP', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 0, '', 0, 0, '', 1261931032, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `people`
--

DROP TABLE IF EXISTS `people`;
CREATE TABLE IF NOT EXISTS `people` (
  `Id` mediumint(8) unsigned NOT NULL auto_increment,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(70) NOT NULL,
  `BirthDate` date NOT NULL,
  `Gender` enum('m','f') default NULL,
  `Done` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `people`
--

INSERT INTO `people` (`Id`, `FirstName`, `LastName`, `BirthDate`, `Gender`, `Done`) VALUES
(1, 'Jill', 'Trust', '1980-12-12', 'f', 50),
(2, 'Trevor', 'Doug', '1980-06-21', 'm', 94),
(3, 'Stacy', 'Elis', '1980-01-24', 'm', 23),
(4, 'Phil', 'Tip', '1999-12-04', 'f', 63),
(5, 'Stark', 'Qwest', '1989-08-01', 'f', 70),
(6, 'Ian', 'Bob', '1989-08-01', 'f', 89),
(7, 'Tom', 'Steph', '1908-12-25', 'm', 1),
(8, 'Chris', 'Rich', '2003-09-03', 'f', 33);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `quotations`
--

DROP TABLE IF EXISTS `quotations`;
CREATE TABLE IF NOT EXISTS `quotations` (
  `EmpCdg` char(2) NOT NULL,
  `DocNro` char(10) NOT NULL,
  `AgeCdg` char(3) default NULL,
  `Paxs` int(11) default NULL,
  `Dsc` varchar(100) default NULL,
  `SerNum` int(11) default NULL,
  `NumSerDet` int(11) default NULL,
  `NumPaxDet` int(11) default NULL,
  `ImpValVta` float default NULL,
  `ImpIgv` float default NULL,
  `ImpTot` float default NULL,
  `ImpIgvNow` float default NULL,
  `MonTip` char(1) default NULL,
  `Sts` char(1) default NULL,
  `AnuFlg` char(1) default NULL,
  `ValPreFlg` char(1) default NULL,
  `FacNro` char(10) default NULL,
  `PndFlg` char(1) default NULL,
  `StsPnd` char(1) default NULL,
  `FecLimPrePag` date default NULL,
  `Obs` mediumblob,
  `Ema` varchar(254) default NULL,
  `DocRes` varchar(20) default NULL,
  `PerRes` varchar(50) default NULL,
  `UsuAdd` char(4) default NULL,
  `FecAdd` date default NULL,
  `TimAdd` char(14) default NULL,
  `UsuChg` char(4) default NULL,
  `FecChg` date default NULL,
  `TimChg` char(14) default NULL,
  `fectrn` date default NULL,
  `ImpTipCam` float default NULL,
  `AfeIgvflg` char(1) default NULL,
  `FecPriSer` date default NULL,
  `EmailEnviado` mediumblob,
  `EmailRecibido` mediumblob,
  `FileHTML` varchar(254) default NULL,
  `Length` int(11) default NULL,
  `EmaFlg` char(1) default NULL,
  `Color1` int(11) default NULL,
  `Color2` int(11) default NULL,
  `tipe` varchar(1) NOT NULL,
  `lang` varchar(5) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `catalog_prom` varchar(10) NOT NULL,
  `timestamp` bigint(10) NOT NULL,
  `SerCdg` varchar(10) NOT NULL,
  `price1` float NOT NULL,
  `pricet` float NOT NULL,
  `promo_cat` varchar(10) NOT NULL,
  `cur_datime` bigint(10) NOT NULL,
  `attention` varchar(20) NOT NULL,
  PRIMARY KEY  (`SerCdg`,`DocNro`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `quotations`
--

INSERT INTO `quotations` (`EmpCdg`, `DocNro`, `AgeCdg`, `Paxs`, `Dsc`, `SerNum`, `NumSerDet`, `NumPaxDet`, `ImpValVta`, `ImpIgv`, `ImpTot`, `ImpIgvNow`, `MonTip`, `Sts`, `AnuFlg`, `ValPreFlg`, `FacNro`, `PndFlg`, `StsPnd`, `FecLimPrePag`, `Obs`, `Ema`, `DocRes`, `PerRes`, `UsuAdd`, `FecAdd`, `TimAdd`, `UsuChg`, `FecChg`, `TimChg`, `fectrn`, `ImpTipCam`, `AfeIgvflg`, `FecPriSer`, `EmailEnviado`, `EmailRecibido`, `FileHTML`, `Length`, `EmaFlg`, `Color1`, `Color2`, `tipe`, `lang`, `comment`, `catalog_prom`, `timestamp`, `SerCdg`, `price1`, `pricet`, `promo_cat`, `cur_datime`, `attention`) VALUES
('', 'DAT-1', 'DAT', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'rrrrr@sss', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'fr', 'comentario esto es lo que yo opino de esto no debe contener estas caracteristicas ok????????', '', 0, 'AE02', 50, 0, '', 1261445490, 'aaaaaaa'),
('', 'DAT-1', 'DAT', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'rrrrr@sss', NULL, NULL, NULL, '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', 'es', 'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv', '', 0, 'AE08', 327.5, 0, '', 1261445490, 'aaaaaaa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

DROP TABLE IF EXISTS `servicios`;
CREATE TABLE IF NOT EXISTS `servicios` (
  `EmpCdg` char(2) character set latin1 NOT NULL,
  `SerCdg` char(4) character set latin1 NOT NULL,
  `SerDsc` varchar(50) character set latin1 NOT NULL,
  `SerDscAbr` varchar(20) character set latin1 NOT NULL,
  `SerPre` float default NULL,
  `SerAgeCdg` char(3) character set latin1 default NULL,
  `SerUsuAdd` char(4) character set latin1 default NULL,
  `SerFecAdd` date default NULL,
  `SerUsuChg` char(4) character set latin1 default NULL,
  `SerFecChg` date default NULL,
  `SerTimChg` char(14) character set latin1 default NULL,
  `hotusuadd` char(4) character set latin1 default NULL,
  `hotfecadd` date default NULL,
  `hottimadd` varchar(14) character set latin1 default NULL,
  `levels_users` tinyint(4) default NULL,
  `tarif_cdg` varchar(5) character set latin1 default NULL,
  PRIMARY KEY  (`EmpCdg`,`SerCdg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Volcar la base de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`EmpCdg`, `SerCdg`, `SerDsc`, `SerDscAbr`, `SerPre`, `SerAgeCdg`, `SerUsuAdd`, `SerFecAdd`, `SerUsuChg`, `SerFecChg`, `SerTimChg`, `hotusuadd`, `hotfecadd`, `hottimadd`, `levels_users`, `tarif_cdg`) VALUES
('', 'DFT', 'servicio de recorrido alrededor de la plaza', '', 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PAE'),
('', 'BNG', 'servicio de reventa de entradas al circo', '', 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PAE'),
('', 'RDV', 'ascenso al Misti', '', 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PAE'),
('', 'CHA', 'Ascenso al Chachani', '', 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'PAE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `serviciosxagencia__`
--

DROP TABLE IF EXISTS `serviciosxagencia__`;
CREATE TABLE IF NOT EXISTS `serviciosxagencia__` (
  `AgeCdg` char(3) NOT NULL,
  `SerCdg` varchar(10) NOT NULL,
  `serdsc` varchar(50) default NULL,
  `UsuAdd` char(4) default NULL,
  `TimChg` char(14) default NULL,
  `IPAdd` varchar(15) default NULL,
  PRIMARY KEY  (`AgeCdg`,`SerCdg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `serviciosxagencia__`
--

INSERT INTO `serviciosxagencia__` (`AgeCdg`, `SerCdg`, `serdsc`, `UsuAdd`, `TimChg`, `IPAdd`) VALUES
('PAS', 'AS01', 'TRANSFER R', 'ADMN', NULL, ''),
('PAS', 'AS02', 'CITY TOUR ', 'ADMN', NULL, ''),
('PAS', 'AS03', 'TOUR CAMPI', 'ADMN', NULL, ''),
('PAS', 'AS04', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS05', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS06', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS08', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS09', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS10', 'CAÑON DEL ', 'ADMN', NULL, ''),
('PAS', 'AS11', 'ASENSOAL M', 'ADMN', NULL, ''),
('PAS', 'AS12', 'ASENSO AL ', 'ADMN', NULL, ''),
('ANT', 'PT02', 'TRANSFER AREQUIPA - PUNO', 'ADMN', NULL, ''),
('PAE', 'AE01', 'TRANSFER RADIO URBANO CON GUIA', 'ADMN', NULL, ''),
('PAE', 'AE02', 'CITY TOUR CONVENCIONAL + STA.', 'ADMN', NULL, ''),
('PAE', 'AE03', 'TOUR CAMPIÑA', 'ADMN', NULL, ''),
('PAE', 'AE04', 'CAÑON DEL COLCA 1D', 'ADMN', NULL, ''),
('PAE', 'AE05', 'CAÑON DEL COLCA 2D/1N', 'ADMN', NULL, ''),
('PAE', 'AE06', 'CAÑON DEL COLCA-PUNO 2D/1N', 'ADMN', NULL, ''),
('PAE', 'AE07', 'CAÑON DEL COLCA VIVENCIAL 2D/1', 'ADMN', NULL, ''),
('PAE', 'AE08', 'CAÑON DEL COLCA VIVENCIAL 3D/2', 'ADMN', NULL, ''),
('PAE', 'AE09', 'CAÑON DEL COLCA TREKING 2D/1N', 'ADMN', NULL, ''),
('PAE', 'AE10', 'CAÑON DEL COLCA TREKING 3D/2N', 'ADMN', NULL, ''),
('PAE', 'AE11', 'ASCENSO AL MISTI 2D/1N', 'ADMN', NULL, ''),
('PAE', 'AE12', 'ASCENSO AL CHACHANI 2D/1N', 'ADMN', NULL, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subservicios`
--

DROP TABLE IF EXISTS `subservicios`;
CREATE TABLE IF NOT EXISTS `subservicios` (
  `EmpCdg` char(2) collate latin1_general_ci NOT NULL,
  `SerCdg` char(6) collate latin1_general_ci NOT NULL,
  `SerDsc` varchar(50) collate latin1_general_ci NOT NULL,
  `SerDscAbr` varchar(20) collate latin1_general_ci NOT NULL,
  `SerPre` float default NULL,
  `serAgeCdg` varchar(3) collate latin1_general_ci default NULL,
  `serUsuAdd` char(4) collate latin1_general_ci default NULL,
  `sertFecAdd` date default NULL,
  `serTimAdd` char(14) collate latin1_general_ci default NULL,
  `serUsuChg` char(4) collate latin1_general_ci default NULL,
  `serFecChg` date default NULL,
  `serTimChg` char(14) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`EmpCdg`,`SerCdg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Volcar la base de datos para la tabla `subservicios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifarios`
--

DROP TABLE IF EXISTS `tarifarios`;
CREATE TABLE IF NOT EXISTS `tarifarios` (
  `id` int(11) NOT NULL auto_increment,
  `descript` varchar(50) default NULL,
  `tarif_cdg` varchar(5) default NULL,
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `tarifarios`
--

INSERT INTO `tarifarios` (`id`, `descript`, `tarif_cdg`) VALUES
(1, 'tarifarios economicos', 'PAE'),
(2, 'tarifarios especiales de lujo', 'ACARO'),
(3, 'transferencias en bus aqp', 'ACER');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifasdetalle`
--

DROP TABLE IF EXISTS `tarifasdetalle`;
CREATE TABLE IF NOT EXISTS `tarifasdetalle` (
  `id` int(11) NOT NULL auto_increment,
  `SerCdg` varchar(10) NOT NULL,
  `AgeCdg` char(5) NOT NULL,
  `Rng` char(21) NOT NULL,
  `Pre` float default NULL,
  `FecIni` date default NULL,
  `FecFin` date default NULL,
  `UsuAdd` char(4) default NULL,
  `FecAdd` date default NULL,
  `TimAdd` char(14) default NULL,
  `UsuChg` char(4) default NULL,
  `FecChg` date default NULL,
  `TimChg` char(14) default NULL,
  `IPAdd` varchar(15) default NULL,
  `IPChg` varchar(15) default NULL,
  `NumLin` int(11) NOT NULL default '0',
  `PaxIni` int(11) NOT NULL default '0',
  `PaxFin` int(11) NOT NULL default '0',
  `EmpCdg` char(2) NOT NULL,
  PRIMARY KEY  (`AgeCdg`,`SerCdg`,`PaxIni`,`PaxFin`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `tarifasdetalle`
--

INSERT INTO `tarifasdetalle` (`id`, `SerCdg`, `AgeCdg`, `Rng`, `Pre`, `FecIni`, `FecFin`, `UsuAdd`, `FecAdd`, `TimAdd`, `UsuChg`, `FecChg`, `TimChg`, `IPAdd`, `IPChg`, `NumLin`, `PaxIni`, `PaxFin`, `EmpCdg`) VALUES
(1, 'ASC', '-1', '', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(2, 'ASC', '-1', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 2, ''),
(3, 'ASC', '-1', '', 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3, 3, ''),
(4, '13', 'ESA', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(5, '13', 'ESA', '', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 20, ''),
(6, '12', '-1', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(7, '12', '-1', '', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 2, ''),
(8, '2', 'KTK', '', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(9, '2', 'KTK', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 5, ''),
(10, '1', '', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(12, 'RDV', '', '', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(13, 'RDV', '', '', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 10, ''),
(14, 'RDV', '', '', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 11, 20, ''),
(15, 'CHA', '', '', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, ''),
(16, 'CHA', '', '', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 4, ''),
(17, 'CHA', '', '', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 5, 20, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `username` varchar(16) NOT NULL default '',
  `password` varchar(16) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `lastlogin` bigint(10) default NULL,
  `newlogin` bigint(10) default NULL,
  `admin` varchar(5) NOT NULL default '',
  `status` tinyint(1) unsigned NOT NULL default '0',
  `added` bigint(10) default NULL,
  `comments` text,
  `company` varchar(50) default NULL,
  `website` varchar(70) default NULL,
  `privileges` smallint(6) default NULL,
  `AgeCdg` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `tickets_users_admin` (`admin`),
  KEY `tickets_users_status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `email`, `lastlogin`, `newlogin`, `admin`, `status`, `added`, `comments`, `company`, `website`, `privileges`, `AgeCdg`) VALUES
(1, 'admin', 'admin', 'admin', 'algo', NULL, NULL, 'Admin', 1, NULL, NULL, NULL, NULL, 128, 'KTK'),
(8, '10', '10', '10', '10', NULL, NULL, 'User', 1, 1261929245, NULL, NULL, NULL, NULL, 'IKP');

-- --------------------------------------------------------

--
-- Estructura para la vista `esta`
--
DROP TABLE IF EXISTS `esta`;

DROP VIEW IF EXISTS `esta`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `agencia`.`esta` AS select `agencia`.`quotations`.`EmpCdg` AS `EmpCdg`,`agencia`.`quotations`.`DocNro` AS `DocNro`,`agencia`.`quotations`.`AgeCdg` AS `AgeCdg`,`agencia`.`quotations`.`Paxs` AS `Paxs`,`agencia`.`quotations`.`Dsc` AS `Dsc`,`agencia`.`quotations`.`SerNum` AS `SerNum`,`agencia`.`quotations`.`NumSerDet` AS `NumSerDet`,`agencia`.`quotations`.`NumPaxDet` AS `NumPaxDet`,`agencia`.`quotations`.`ImpValVta` AS `ImpValVta`,`agencia`.`quotations`.`ImpIgv` AS `ImpIgv`,`agencia`.`quotations`.`ImpTot` AS `ImpTot`,`agencia`.`quotations`.`ImpIgvNow` AS `ImpIgvNow`,`agencia`.`quotations`.`MonTip` AS `MonTip`,`agencia`.`quotations`.`Sts` AS `Sts`,`agencia`.`quotations`.`AnuFlg` AS `AnuFlg`,`agencia`.`quotations`.`ValPreFlg` AS `ValPreFlg`,`agencia`.`quotations`.`FacNro` AS `FacNro`,`agencia`.`quotations`.`PndFlg` AS `PndFlg`,`agencia`.`quotations`.`StsPnd` AS `StsPnd`,`agencia`.`quotations`.`FecLimPrePag` AS `FecLimPrePag`,`agencia`.`quotations`.`Obs` AS `Obs`,`agencia`.`quotations`.`Ema` AS `Ema`,`agencia`.`quotations`.`DocRes` AS `DocRes`,`agencia`.`quotations`.`PerRes` AS `PerRes`,`agencia`.`quotations`.`UsuAdd` AS `UsuAdd`,`agencia`.`quotations`.`FecAdd` AS `FecAdd`,`agencia`.`quotations`.`TimAdd` AS `TimAdd`,`agencia`.`quotations`.`UsuChg` AS `UsuChg`,`agencia`.`quotations`.`FecChg` AS `FecChg`,`agencia`.`quotations`.`TimChg` AS `TimChg`,`agencia`.`quotations`.`fectrn` AS `fectrn`,`agencia`.`quotations`.`ImpTipCam` AS `ImpTipCam`,`agencia`.`quotations`.`AfeIgvflg` AS `AfeIgvflg`,`agencia`.`quotations`.`FecPriSer` AS `FecPriSer`,`agencia`.`quotations`.`EmailEnviado` AS `EmailEnviado`,`agencia`.`quotations`.`EmailRecibido` AS `EmailRecibido`,`agencia`.`quotations`.`FileHTML` AS `FileHTML`,`agencia`.`quotations`.`Length` AS `Length`,`agencia`.`quotations`.`EmaFlg` AS `EmaFlg`,`agencia`.`quotations`.`Color1` AS `Color1`,`agencia`.`quotations`.`Color2` AS `Color2`,`agencia`.`quotations`.`tipe` AS `tipe`,`agencia`.`quotations`.`lang` AS `lang`,`agencia`.`quotations`.`comment` AS `comment`,`agencia`.`quotations`.`catalog_prom` AS `catalog_prom`,`agencia`.`quotations`.`timestamp` AS `timestamp`,`agencia`.`quotations`.`SerCdg` AS `SerCdg`,`agencia`.`quotations`.`price1` AS `price1`,`agencia`.`quotations`.`pricet` AS `pricet`,`agencia`.`quotations`.`promo_cat` AS `promo_cat`,`agencia`.`quotations`.`cur_datime` AS `cur_datime`,`agencia`.`quotations`.`attention` AS `attention` from `agencia`.`quotations`;
