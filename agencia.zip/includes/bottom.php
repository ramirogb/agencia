<link href="styles.php" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<table width="90%"  border="0"   align="<?php echo $maintablealign ?>"  cellpadding="0" cellspacing="0" class="bottom">
  <tr>
    <td style=" padding-left:10px; padding-right:10px; padding-bottom:5px"><div align="center"></div>
      <a href="./"><?php 
echo $sitename;
?> 
      </a>
      <div align="right"><a href="http://www.cromosoft.com" >
        <input name="Facil HelpDesk" type="hidden" id="Facil HelpDesk" value="http://www.cromosoft.com">
      Powered by e-tour</a></div></td>
  </tr>
</table>
<!-- Histats.com START (hidden counter)--> <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script> <a href="http://www.histats.com" target="_blank" title="contador web gratis" ><script type="text/javascript" > try {Histats.start(1,1056830,4,0,1,1,""); Histats.track_hits();} catch(err){}; </script></a> <noscript><a href="http://www.histats.com" target="_blank"><img src="http://sstatic1.histats.com/0.gif?1056830&101" alt="contador web gratis" border="0"></a></noscript> <!-- Histats.com END --> 
<SPAN id=imgObj style="PADDING-RIGHT: 10px; PADDING-LEFT: 13px; FILTER: progid:DXImageTransform.Microsoft.Gradient(gradientType=1,startColorStr=<?php echo $bgcolor; ?>,endColorStr=#FFFFFF); WIDTH: 100%; COLOR: darkred; HEIGHT: 10px; BACKGROUND-COLOR: #FFFFFF">
</SPAN>
