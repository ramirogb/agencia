<?php 
function begin_trans()
{
}
function end_trans()
{
}
function commint_trans()
{
}
function rollback_trans()
{

}

?>