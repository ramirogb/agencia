<html>
<p>Departament of $departament, a response is waiting,</p>
<p>Ticket ID: $id<BR>
 Subject: $subjet<BR>
Post Date:$date<BR>
<BR>
  $message
<BR>
<BR>
$siteurl


