<html>
<p>$rate_response</p>
<p>Ticket ID: $id<BR>
  Subject: $subjet<BR>
  Urgency: $urgency<BR>
Department: $departament</p>
<p> Post Date:$date</p>
<p>____________________________________________________________________<BR>
<BR>
  <BR>
  $message<BR>
____________________________________________________________________</p>
<p>$open_ticket</p>
<p>Or visit: $siteurl with your username and password(registered users). </p>
<p>$footer</p>
<p>&nbsp;</p>
</html>
