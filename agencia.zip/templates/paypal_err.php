<p align="center">
  <?php 
if ($authz<>'TRUE') exit;
?>
</p>
<p align="center">&nbsp;</p>
<?php echo $paypal_err ?>
<p align="center">&nbsp;</p>
