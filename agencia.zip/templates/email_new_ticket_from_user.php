<html>
<p>Dear $name, </p>
<p>Your ticket has now been received. One of our staff members will review it and reply accordingly. Listed below are the details of this ticket</p>
<p>Ticket ID: $id<BR>
  Username: $username<BR>
  Subject: $subjet<BR>
  Urgency: $urgency<BR>
  Department: $departament<BR>
  Post Date: $date<BR>
  ____________________________________________________________________<BR>
  <BR>
  $message<BR>
  ____________________________________________________________________ <BR>
</p>
<p>You can check the status or reply to this ticket online at:<BR>
</p>
<p>$open_ticket</p>
<p>Or visit: $siteurl with your username and password(registered users). </p>
<p>$footer</p>
<p>&nbsp;</p>
</html>
