<?php //for security was included, but disabled for a time
//if $_GET['action']=='ssertfdgtgh5467hgfgd5434'
//if ($authz<>'TRUE')
// exit; 
?><html><head></head><body bgcolor="white" topmargin="0" leftmargin="0"><div align="left"></div>
<script language="javascript" type="text/javascript">
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}
</script>
<table border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="10"></td>
    <td align="left"><font size="2" face="verdana">
      <strong>Que pensez-vous de notre service?</strong></font></td>
  </tr>
  <tr>
    <td width="10"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">
<form action="<?php echo $_SERVER['PHP_SELF'];?>?action=poll2&case=<?php echo stripslashes(  trim(($_GET['case']))); ?>"
      method="POST">
  <table cellspacing="0" width="100%" cellpadding="4">
    <tr>
      <td align="right" valign="top" width="411" height="20">&nbsp;</td>
      <td align="left" valign="top" colspan="3" height="20" bgcolor="#CDE4FF">
          <strong><font color="#000000" face="Verdana" size="2">Service</font></strong></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td colspan="2" align="left" valign="top" bgcolor="#FFFFFF">
        <font size="2" face="Verdana">Veuillez &eacute;valuer votre satisfaction globale avec nos respons</font></td>
    </tr>

    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="1" value="5">
             5 tr&egrave;s bien</font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"><input name="staff" type="hidden" id="staff" value="<?php echo trim($_GET['mdxr']); ?>">
        <input name="tix" type="hidden" id="tix" value="<?php echo  urldecode( $_GET['tix']); ?>"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="1" value="4">
            
            4
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="1" value="3">
            
            3
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="1" value="2">
            
            2
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="1" value="1">        
            tr&egrave;s pauvre</font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td colspan="2" align="left" valign="top" bgcolor="#FFFFFF">
        <font size="2" face="Verdana">Veuillez &eacute;valuer l'exactitude de notre r&eacute;ponse:</font>
      </td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="2" value="5">
            
            5 tr&egrave;s bien</font></td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="2" value="4">
            
            4
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="2" value="3">
            
            3
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="2" value="2">
            
            2
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="2" value="1">
            
            1        
            tr&egrave;s pauvre</font> 
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td colspan="2" align="left" valign="top" bgcolor="#FFFFFF">
        <font size="2" face="Verdana">Veuillez &eacute;valuer la promptitude de notre r&eacute;ponse:</font>
      </td>
    </tr>

    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="3" value="5">
            
            5 tr&egrave;s bien</font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="3" value="4">
            
            4
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="3" value="3">
            
            3
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="3" value="2">
            
            2
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="3" value="1">
            
            1 tr&egrave;s pauvre</font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td colspan="2" align="left" valign="top" bgcolor="#FFFFFF">
        <font size="2" face="Verdana">Veuillez &eacute;valuer la professionnalisme de notre r&eacute;ponse:</font>
      </td>
    </tr>

    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="4" value="5">
            
            5 tr&egrave;s bien</font></td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="4" value="4">
            
            4
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="4" value="3">
            
            3
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="4" value="2">
            
            2
        </font>
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="45">&nbsp;</td>
      <td align="left" valign="middle" bgcolor="#FFFFFF" width="229">
        <font size="2" face="Verdana">
            <input type="radio" name="4" value="1">
            
            tr&egrave;s pauvre</font> 
      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF" width="531"></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#FFFFFF">&nbsp;</td>
      <td align="right" bgcolor="#FFFFFF" colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Commentaires:
        </font>        <textarea name="comment" cols="50"  
  rows="3" id="comment" onKeyDown="limitText(this.form.comment,this.form.countdown,255);"
		                  onKeyUp="limitText(this.form.comment,this.form.countdown,255);"></textarea>
        <input  readonly="true" name="countdown" type="text" id="countdown" size="4"></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#FFFFFF" width="411">&nbsp;</td>
      <td align="right" bgcolor="#FFFFFF" colspan="2"> 
        <p align="left"><font face="Verdana" size="2">
          <input type="submit" value="Submit">
          <input type="reset" value="Clear Form">
          </font></p> 
      </td>
    </tr>

  </table>
</form>
    </td> 
  </tr>   
  <tr>
    <td colspan="2">
        <div align="center">
        <center>
            <table border="0" cellpadding="0" cellspacing="0" width="600">
                <tr>
                    <td>
                        <p><center class="menu6"> <?php echo $text_titlelink; ?>
                        </center> </p>
                    </td>
                </tr>
            </table>
        </center>
        </div>
    </td>
  </tr>
</table>
<div id="hwdc" class="switchcontent"><br> </div>
</body>
</html>