<?php
	$charset = 'ISO-8859-1';
	//NAVIGATION BAR
	
	$text_login    = 'Login';
	$text_register = "Don't have an account already?, then Register";
	$text_resend   = 'Forgot?';
	$text_help     = 'Help';
	$the_users     ='Users';
    $the_usersstaff     ='Staff-Users';
	$departaments     ='Departments';
	$settings         ='Settings';
	$reports          ='Reports';
	$select_a_user    ='Select a user to create a ticket if this list is not long: or go to Users and click the button  \'Create ticket\' for the selected user';
	$kb='Articles';
	// LOGIN PAGE AND LOGIN ERROR	
    $index_='Index';
	$profile='My Profile';
    $rememberme= 'Remember me,save password for future logins';
	$text_username  = 'Username';
	$text_password  = 'Password';
	$text_login     = 'Log In';
	$text_loginpage = '	<b>You have entered an invalid username/password
				combination. Please try again.</b><br /><br />If you have lost your user and password click Forgot.<br /><br />Enter your
				and the system will email your details to you.';
	$text_loginback = 'Back';
	$email_confirm="Thanks, an email has been sent to you. Once you receive it, you'll need to confirm your registration clicking a link in 24hours.";
    $replies='Replies';
	$send_login='Send Login information to your email';
	$wait_for_login='In seconds your username and password will be sent to your email.';
	// RESEND DETAILS PAGE AND RESEND ERROR
	$text_resendpage  = '	The email must match the one you used when you created your account. The system will send the username and password.';
	$text_email       = 'Email';
	$text_submit      = 'Submit';
	$text_resenderror = '	Sorry, the details you have entered do not match anything we have in our Database.<br /><br />
				Hit the back button to try again.';
	$text_resendback  = 'Back';

	// REGISTER PAGE AND REGISTER ERROR
    $text_950='*** Value(s) are too short:';
    $text_951=' Use 4-20 chars, from: a-z, A-Z, 0-9';	
	$text_regname     = 'Name:';
	$text_reguser     = 'Username:';
	$text_regpass     = 'Password:';
	$text_regemail    = 'Email:';
	$text_regsubmit   = 'Submit';
	$text_notes='Notes for internal use(optional,phone,etc.)';
	$usernameunique='Username must be unique*.';
	$text_regpageerr  = '	Please complete all the fields and make sure the email is the correct format.
				<br /><br />Hit the back button to try again.';
	$text_regpagback  = 'Back';
	$text_regusererr  = '	Sorry someone else is already using that Username.<br /><br />

				Hit the back button to try again.';

	$text_regconf     = 'You have been registered and sent a confirmation email -  ';

	$text_regsubject  = 'Thank You For Registering';
	$createaccount='Create New Account';
//         Users AREA
	// NAVIGATION TOP BAR
	$to_rate_responses= 'To rate our service please visit: ';
	$text_titlelink = 'Facil HelpDesk';
	$text_title	= 'Support Tickets Manager';
	$text_titlereq	= 'Reservation';
	$text_titleope	= 'Quotes';
	$text_titleclo	= 'Services';
	$text_titlehold	= 'Hold Messages';
	$text_titlelog	= 'Logout';
	// HOME PAGE LISTING OF TICKETS
	$text_listtitle = 'Recent Tickets:';
	$text_listmsg   = 'Click on the Ticket Number to read the ticket.';
	$text_listtik   = 'Ticket ID [Replies]';
	$text_listsub   = 'Subject';
	$text_listdat   = 'Date';
	$text_listtim   = 'Time';
	$text_listurg   = 'Urgency';
	$text_liststa   = 'Status';
	$text_listnon   = 'You have no recent tickets for your account.';
	// SEARCH PAGE LISTINGS - TABLE HEADINGS SAME AS ABOVE
	$text_searchtitle = 'Search Results:';
	$text_searchmsg   = 'Click on the Ticket Number to read the ticket.';
	$text_searcherr   = 'Sorry but the search returned Zero results please try again.';
	// VIEW TICKET PAGE
	$test_view = '';
	//ARTICLES BASE
	$insert_article='Insert Title, variable of URL(optional) and Content';
	$title_article='Title of    this page';
	$categorie_article='Categories';
	$admin_categorie='Edit Categories';
	$image_article='If you want a image will be shown with the page, or delete the current image if available';
	$create_page='Create article or page';
	$meta='META TAGS Secci&oacute;n';
	$identifier='Write an &quot;identifier&quot; for this page';
	$showdate='Show date of modification';
	$datex='Last update';
	$description='description';
	$keywords='Keywords';
	$insert_content='Insert the content of the page(only has text and links to images and others files).';
	$source_reference='Source of reference';
	$author='Author of this document';
	$is_listed='Is visible';
	$is_yes='Yes';
	$is_not='Not';
	$only_for_reg_users='These fields* will be saved only for registered users';
	$limit_of_tickets='No more tickets can be created, please wait.';
	$label_limit_tickets='Min. time between tickets:';
	$available='You can create: ';
	$profile='Profile';
	$chan_password='Changing your password will require a new login';
	$departament='Departament';
	$close_ticket='Close ticket';
	$reopen_ticket='Reopen ticket';
	$hold_ticket='Hold ticket';
	$posted_by='Posted by:';
	$respond='Respond';
	$banuser='Suspend user';
	$question_='Dialog question:';
	$response_='Response';
	$uploadfile='Optional File Attachment:';
	//NOTIFICATIONS
	$dear='Dear';
	$theticket='The ticket:';
    $wasclosed='Was closed';
	$ticketclosed='Your ticked was closed';
	$the_subjetqq='New Ticket assigned';
	$the_subjet_trans='Ticket transferred';
	$openticket=' Open entire ticket';
    $closeticket='Close Ticket';
	$newticket='New Message';
	$previosmesages=' Previous Messages (Latest First):';
	$msg1='This is a test of email, the test was succesfull! ';
	$msg2='This is a test';	
	$errorchangingticket='Was not posible to change status of ticket';
	$limit_size='Max.';
	$track_unregistered="Track your ticket*";
	$track_unregistered2="* ticket ID y Key est�n incluidos en la primera notificaci�n de su solicitud si envi� un email como usuario no registrado.";
	$help_ticket="Our booking system provides instant prices and reservations for our touristic services.
	the software has 3 options: (1)Service Listing, Create quotes (2) and Create Reservations (3), quotes are sent to your email.
	 . <BR>Take in consideration that we aprove reservations after 24hours, and you will get a notificacion by email.
	  For using the software you need an account, after of registering you will be contacted before of activating your account, it could take several hours or days. Thanks for your undestanding.<BR> 
	  	   <BR>";
	   $error_msg1='We were not able to decode your email and insert it in our Ticket System, please send once again an email but a basic email or use other email client';
	   $error_msg2='There were an error processing your email';
	   $reparation='Mantenimiento';
	   $namex='Usuario';
	   $namey='Nombre';
	   $subx='Asunto';
 	   $new_ticket1='Nuevo ticket de soporte';
	   $cannedreply='Respuesta r�pida:';
	   $store_reply='Almacenar la respuesta para uso posterior';
	   $subjetcanned='Asunto';
	   $eta='Tiempo de llegada:';
   	   $edit='Editar';
	   $internal='Comentario interno';
	   $emails_deps='Emails de Departamentos';
	   $adduser='Create User';
	   $performance='My rendimiento';
	   $npolls='Solo 5 encuentas por Ticket son permitidas.';
	   $errorpoll=' No se pudo grabar la encuesta, si cree que es un error por favor contacte el Area de Soporte.';
	   $your_responseq='Lo agregaste al Ticket';
	     $new_tic='Mi Ticket';
		 $service_quo='Code Quote ';
 		 $service_reserv='Code Reservation';
		 $select_catalog='Select Category or Catalog: ';
		 $select_date='Select date(s) to continue';
		 $text_listsub   = 'Agency';
		 $asunto_cotiza='Your Quote';
 		 $asunto_reserv='Your Reserv';
		 $quotations='Quotes';
		 $reservs='Reservations';
		 $date_reserv='Date';
		 $hour_reserv='Hours';
		 $minutes_reserv='Minutes';
		 $service_reserv='Reservation of Service:';
		 $descript_reserv='Description';
		 $type_reserv='Type of Service';
	$lang_reserv='Languaje';
	$unit_price='Individual Price';
	$total_reserv='Total';
	$text_history='Mi file';
	$no_selection='Cart empty, select services of Catalog.';
	$price_='Price';
	$paxes='Passengers';
	$comment='Comments';
	$Service_priv='Private';
	$Service_shared='Shared';
	  $english='Ingl�s';
	  $spanish='Espa�ol';
	  $french='Frances';
	  $german='Alem�n';
      $italian= 'Italiano';
	  $port='Portugues';		
	  $usuarios='Users'; 
	  $only_admin='No permissions, only Admin';  
	  $confirmed='Confirmated';
	  $pending='Recibed';
	  $canceled='Cancelated';
	  $service='Service';
	  $change_descript_catalog = 'Edit Category';
	  $services='Services';
	  //installation
	  $step11=' Basic Settings will be stored at configuration.php';
	  $step22= 'New tables will be created  for a  new installation when you click Submit';
	  $step33='  An administrator will be created If you only want to change Database or reset administrative user click';
	  $warning=' <span class="red2"><strong>If these tables exists in your database those will be overwriten and your data lost!</strong></span>';
	  $backup=' <span class="Estilo1"><strong>Backup  your database before of doing any action! </strong></span>';
	  $men5='Fill every field of the Form, specially fields of Mysql Database and E-email. Click Submit, a configuration file will be created and new tables will be created inside your Database';
	  $empresas='Operators';	  
	  $servicios='Tours Services';
	  $requestf='Request Feature';
	  $date_ini='Start Date';
	  $date_fin='End Date';
	  $predefault='Make default';
	  $all='All';
	  $wizard1='Create price for a Servic, Select a Category, select type: Shared or Pivate and if only applies to one Operator';
	  $quoteH='QUOTE';
	  $reservH='RESERVATION';
	  $selectme='Select';
	  $agencias_='Tour Operators';
	  $new_sms='Reservation generated for ';
	  $monto='Cuantity';
	  $taxes='Taxes 19%';
	  $first_service_=' Date of First Service:';
    $insert_Agency='Insert Agency';
	$create_code_agency='Insert Code of Agency';
	$name_agency='Name of Tour Operator';
	$address='Address';
	$telephone='Telephone';
	$telephone24='Telephone 24h';
	
	$fax='Fax';
	$contact='Contact or administrator';
	$tax_number='Tax Number';
	$cellular1='Cellular 1';
	$cellular2='Cellular 2';
	$cellular3='Cellular 3';
	 $codeCatalog='Catalog Code';
	 $insert_Catalog='Insert Catalog';
	 $code_service='Service Code';
    $exclusive='Exclusive for one agency';
	 $insert_service='Insert Service';
	 $nranges='N ranges for prices';
	 $ovewrite='Prices will be overwritten if you continue';
	 $cat1='Categories of Services';
	  $prices1='Prices';
	  $filter='Filter: ';
   $coin= 'Values are in USD $';
   $calcule='Calcule';
   	  $confirm_='Your reservation will be confirmated in 24hours by email ';
  	  $name_group='Name group';
	$limit_prep='Limit to prepay - 30 days';
	$owe='They Owe You';
	$req_deposit='Req. Deposit';
	$amount='Amount';
	$add_trans='Add Transaction';
	$payments='Payments';
	$enter='Enter';
	$archived='Archived';
	$type_pay='Tipo de Pago';
	$messages='Messages';
	$messages_open='Open Messages';
	$messages_closed='Closed Messages';	
	$urgency_levels='Urgency Levels';
	$dashboard='Dashboard';
    $come_back='Come Back to Booking..';
	$messages_categoty='Permissions for managing Messages';
	$messages_categoryes='Create New Categories for Messages';
	$half_payment='Incomplete Payments';
	$waiting_advance='Waiting initial payment';
	$waiting_attention='New bookings';
	$reservations='Bookings';
	$create_message='Create  Message';
	$canceled='Canceled';
	$search_booking='Search_booking';
	$archived_bookings='Archived_bookings';
	$are_you_sure='Are you sure?';
?>