Translate these files to your languaje.
Only english and spanish file are completed.